import java.io.*;
import java.net.*;
import java.util.ArrayList;


/////////////////////////////////Sever!!!!!!!!!!!!!!!!!!!!!!!!!

public class Server {
    private ServerSocket serverSocket;
    private Client_Handler clientHandler;
    
    private static boolean gameInProgress = false;


    public Server(ServerSocket serverSocket){
        this.serverSocket = serverSocket;

    }

    public  void startServer(int contador){
        try{
            while (true){
                Socket clientSocket = serverSocket.accept();
                if (clientHandler.waitingClients.size() == 2){
                    gameInProgress = true;
                    System.out.println("AHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH");
                    System.out.println("Cliente conectado desde " + clientSocket.getInetAddress().getHostAddress());
                    if(!clientHandler.clientHandlers.contains(clientHandler)){
                    clientHandler.ListoJugar.add(clientHandler);
                }
            }
                contador = contador+1;

                Client_Handler clientHandler = new Client_Handler(clientSocket,contador,gameInProgress);
                //System.out.println(gameInProgress);
                //System.out.println(contador);
                if (!gameInProgress) {
                    System.out.println("Fuck!!");
                    gameInProgress = true;
                    System.out.println(gameInProgress);
                    Thread thread = new Thread(clientHandler);
                    thread.start();
                }

                //contador = 0; // Reinicia el contador para el siguiente juego
                else {
                // Agrega a los clientes en cola para el siguiente juego
                clientHandler.sendQueueMessage(); // Envía un mensaje de cola al cliente
                if(! clientHandler.clientHandlers.contains(clientHandler)){
                clientHandler.ListoJugar.add(clientHandler);
                } // Agrega el cliente a la cola

            }

        }
    }catch(IOException e){

        }
    }

    public static void main(String[] args) {
        try {
            int contador = 0;
            ServerSocket serverSocket = new ServerSocket(3000);
            System.out.println("Servidor esperando conexiones...");
            
            Server server = new Server(serverSocket);
            server.startServer(contador);

                
            


            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void setGameInProgress(boolean inProgress) {
        gameInProgress = inProgress;
    }


    
}


