import java.io.*;
import java.net.*;

class ClientHandler extends Thread {
    private Socket clientSocket;
    private PrintWriter out;
    private ClientHandler next;
    private static int nextIdentifier = 1;
    private int contador1;

    public ClientHandler(Socket socket,int contador) {
        this.contador1 = contador;
        this.clientSocket = socket;
        System.out.println(contador);
        
        
        try {
            this.out = new PrintWriter(socket.getOutputStream(), true);
        } catch (IOException e) {
            e.printStackTrace();
        }  
    }

    public void run() {
        try {
            // Obtener flujos de entrada y salida del cliente
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream());

            int identifier = getNextIdentifier();
            out.println(identifier);

            // Agregar el manejador del cliente a la lista enlazada
            addClient(this);

            // Notificar a todos los clientes que un nuevo usuario se ha conectado
            String newUserMessage = "Nuevo usuario conectado: " + clientSocket.getInetAddress().getHostAddress();
            broadcast(newUserMessage);

            System.out.println(contador1);
            if (contador1==1){
            contador1 = contador1 +1;
                String clientMessage;
            clientMessage = "e";
            clientMessage = in.readLine();
                String messageToSend = "Cliente " + clientSocket.getInetAddress().getHostAddress() + ": " + clientMessage;
                broadcast(messageToSend);
                String ahh = "Inicio";
                broadcast(ahh);
            
            boolean manzana = true;
            while (manzana == true) {
                // Procesa y retransmite el mensaje a todos los clientes
                clientMessage = in.readLine();
                System.out.println(clientMessage);
                broadcast(clientMessage);
                //break;
                

                
            }

                if (clientMessage == "4") {
                    manzana = false;
    // Code to execute if the condition is true
}

            

            // El cliente ha salido del bucle, por lo que se elimina de la lista enlazada y se notifica a los demás
            removeClient(this);
            String userLeftMessage = "Usuario desconectado: " + clientSocket.getInetAddress().getHostAddress();
            broadcast(userLeftMessage);

            // Cierra la conexión con el cliente
            clientSocket.close();
        }
        } catch (IOException e) {
            // Maneja la excepción de E/S cuando el cliente se desconecta
            System.out.println("Cliente desconectado desde " + clientSocket.getInetAddress().getHostAddress());
            removeClient(this);
            String userLeftMessage = "Usuario desconectado: " + clientSocket.getInetAddress().getHostAddress();
            broadcast(userLeftMessage);
        }
    }
    private static synchronized int getNextIdentifier() {
        return nextIdentifier++;
    }

    // Método para enviar un mensaje en broadcast a todos los clientes
    private static void broadcast(String message) {
        ClientHandler current = firstClient;
        while (current != null) {
            current.out.println(message);
            current = current.next;
        }
    }

    // Implementa una lista enlazada personalizada para los clientes
    private static ClientHandler firstClient;

    private static void addClient(ClientHandler client) {
        if (firstClient == null) {
            firstClient = client;
        } else {
            ClientHandler current = firstClient;
            while (current.next != null) {
                current = current.next;
            }
            current.next = client;
        }
    }

    private static void removeClient(ClientHandler client) {
        if (firstClient == client) {
            firstClient = client.next;
        } else {
            ClientHandler current = firstClient;
            while (current != null && current.next != client) {
                current = current.next;
            }
            if (current != null) {
                current.next = client.next;
            }
        }
    }
}

public class Server {
    public static void main(String[] args) {
        try {
            int contador = 0;
            ServerSocket serverSocket = new ServerSocket(3000);
            System.out.println("Servidor esperando conexiones...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Cliente conectado desde " + clientSocket.getInetAddress().getHostAddress());
                ClientHandler clientHandler = new ClientHandler(clientSocket,contador);

                // Crea un nuevo hilo para manejar el cliente
                contador = contador+1;
                System.out.println(contador);    
                clientHandler.start();
                
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


