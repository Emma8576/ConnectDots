
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Objects;
import java.util.Scanner;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;



/** 
 * Esta clase es la encargada de manejar la comunicación con un cliente en un chat.
*/
public class Client_Handler implements Runnable {

    public static ArrayList<Client_Handler> clientHandlers = new ArrayList<>();
    private Socket socket;
    private BufferedReader bufferedReader;
    private BufferedWriter bufferedWriter;
    private String clientUsername;
    private int contador1;
    public static ArrayList<Client_Handler> waitingClients = new ArrayList<>();
    public static ArrayList<Client_Handler> ListoJugar = new ArrayList<>();
    public int contador =0;
    private final Object clientHandlersLock = new Object();
    private final Object waitingClientsLock = new Object();


    boolean gameInProgress;
    private Server Server;

    /**
     * Este constructor es el encargado de que se inicialicen los flujos de entrada/salida, así como obtener el nombre de usuario del cliente que se conecto al servidor.
     *
     * @param socket El socket de la conexión con el cliente.
     */
    public Client_Handler(Socket socket, int contador, boolean gameInProgress1){
        try{
            this.contador1 = contador;
            this.socket = socket;
            this.bufferedWriter =new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())); 
            this.bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            
            this.clientUsername = bufferedReader.readLine(); 
            this.gameInProgress=gameInProgress1;
            System.out.println(gameInProgress);
            
            if (!gameInProgress) {
                clientHandlers.removeIf(Objects::isNull);
                waitingClients.removeIf(Objects::isNull);
                for (Client_Handler client : ListoJugar) {
                    System.out.println("Listo Jugar: " + client);
                }
                if(waitingClients.size() >= 2){
                    if (!clientHandlers.contains(this) || !ListoJugar.contains(this)) {
                    ListoJugar.add(this); 
                    clientHandlers.add(this);
                    }
                }else if (!clientHandlers.contains(this) || !ListoJugar.contains(this)) {
                    clientHandlers.add(this);
                    waitingClients.add(this); 
                }
                for (Client_Handler client : clientHandlers) {
                    System.out.println("Client Handlers: " + client);
                }

                System.out.println("Separación de listas");

                for (Client_Handler client : waitingClients) {
                    System.out.println("Waiting Clients: " + client);
                }
                
                broadcastMessage("SERVER: " + clientUsername + " ha entrado al chat!");
                String ahh = "Me cago";
                System.out.println("Me cago!!!!!!!!");
                broadcastMessage(ahh);
                
            } else {
                System.out.println("Testeo!!!!!!!!");
                for (Client_Handler client : ListoJugar) {
                    System.out.println("Listo Jugar: " + client);
                }
                if(waitingClients.size() >= 2){
                    if (!clientHandlers.contains(this) || !ListoJugar.contains(this)) {
                    ListoJugar.add(this); 
                    clientHandlers.add(this);
                    }
                }else if (!clientHandlers.contains(this) || !ListoJugar.contains(this)) {
                    clientHandlers.add(this);
                    waitingClients.add(this); 
                }
                
                for (Client_Handler client : clientHandlers) {
                    System.out.println("Client Handlers: " + client);
                }
                for (Client_Handler client : waitingClients) {
                    System.out.println("Waiting  Client: " + client);
                }
                startGame(gameInProgress);
                sendQueueMessage(); // Envía un mensaje de cola al cliente
                
            }

            //System.out.println(contador);
        
        } catch (IOException e){
            closeEverything(socket,bufferedReader,bufferedWriter);
        }
    }

    @Override
    public void run(){
        String messageFromClient;
        System.out.println("Cabra!!!!!!!! Gota");
        System.out.println(gameInProgress);
        if(contador == 0){
        if (waitingClients.size() >= 0) {
            System.out.println("Llegue pleaseV49");
            gameInProgress = true;
            contador = 1;
        }
    


        while (gameInProgress){
            try{
            
            System.out.println("Baki!!!!!!!!!!!");
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(socket.getOutputStream());
            
            String newUserMessage = "Nuevo usuario conectado: " + socket.getInetAddress().getHostAddress();
            broadcastMessage(newUserMessage);

            
                contador1 = contador1 +1;
                messageFromClient = in.readLine();
                String messageToSend = "Cliente " + socket.getInetAddress().getHostAddress() + ": " + messageFromClient;
                broadcastMessage(messageToSend);
                String ahh = "Inicio";

                final Scanner sc = new Scanner(System.in);
                System.out.println("Indique el numero de columnas");
                String columnas = sc.nextLine();;//Obtiene el usuario escrito
                System.out.println("Indique el numero de filas");
                String filas = sc.nextLine();;//Obtiene el usuario escrito
                
                broadcastMessage("Inicio" + " " + columnas + " " + filas);
                System.out.println("Inicio" + " " + columnas + " " + filas);
            
            boolean manzana = true;
            while (manzana == true) {
                // Procesa y retransmite el mensaje a todos los clientes
                messageFromClient = in.readLine();
                System.out.println(messageFromClient);
                //broadcastMessage(messageFromClient);
                
                if(messageFromClient.equals("terminar")){
                    broadcastMessage(messageFromClient);
                    waitingClients.remove(0);
                    clientHandlers.remove(0);
                    procesarnuevos();
                    waitingClients.add(ListoJugar.remove(0));
                    System.out.println("Se termino el juego");
                    gameInProgress = false;
                    startGame(gameInProgress);
                    break;

                }
                System.out.println("Llega al broadcast?");
                broadcastMessage(messageFromClient);
                
                

                
            }

            }catch(IOException e){
                closeEverything(socket,bufferedReader,bufferedWriter);
                //break;
            }
        }
    }

      


        



    }

    public synchronized void procesarnuevos() {
        // Remove null elements from clientHandlers
        synchronized (clientHandlersLock){
        clientHandlers.removeIf(Objects::isNull);
        }
        synchronized (waitingClients){
            waitingClients.removeIf(Objects::isNull);
        }
    
        for (int i = 0; i < waitingClients.size(); i++) {
            System.out.println("Waiting clients: " + waitingClients.get(i));
        }
    
        try {
            Thread.sleep(10000);
            if (!ListoJugar.isEmpty()) {
                if (waitingClients.size() <= 1) {
                waitingClients.add(ListoJugar.remove(0));
                System.out.println(waitingClients.size());
                System.out.println("Revision");
                }
                //clientHandlers.addAll(waitingClients);
            }
            
            synchronized (clientHandlersLock){
        clientHandlers.removeIf(Objects::isNull);
        }
        synchronized (waitingClients){
            waitingClients.removeIf(Objects::isNull);
        }
            /* 
            System.out.println("Empiezan las listas");
            for (Client_Handler client : clientHandlers) {
                System.out.println("Client Handlers: " + client);
            }
            System.out.println("Sepa mae listas");
            for (Client_Handler client : waitingClients) {
                System.out.println("Waiting clients: " + client);
            }
            for (Client_Handler client : clientHandlers) {
                System.out.println("Client Handlers: " + client);
            }
            */


        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    

    public void sendQueueMessage() {
        try {
            bufferedWriter.write("SERVER: Esperando en la cola para unirse al juego.");
            bufferedWriter.newLine();
            bufferedWriter.flush();
        } catch (IOException e) {
            closeEverything(socket, bufferedReader, bufferedWriter);
        }
    }
    /**
     * Este método es utilizado para transmitir un mensaje a todos los clientes conectados por ende este mensaje sería uno de broadcast.
     *
     * @param messageToSend Es el mensaje que se va a enviar a todos los clientes.
     */
    public void broadcastMessage(String messageToSend){
        for(Client_Handler clientHandler: waitingClients){
            try{
                if (!clientHandler.clientUsername.equals(clientUsername)){
                    clientHandler.bufferedWriter.write(messageToSend);
                    clientHandler.bufferedWriter.newLine();
                    clientHandler.bufferedWriter.flush();
                }
            }catch(IOException e) {
                closeEverything(socket,bufferedReader,bufferedWriter);
            }
        }
    }
    /**
     * Método para el manejador de cliente, al igual que el avisar a los demás clientes que un usuario se desconecto del chat.
     */
    
     public void removeClientHandler(){
        clientHandlers.remove(this);
        broadcastMessage("SERVER"+clientUsername+" ha abandonado el chat");
    }
    
    /**
     * Este método es utilizado para cerrar los flujos de entrada/salida y el socket.
     *
     * @param socket          El socket a cerrar.
     * @param bufferedReader  El lector de flujo de entrada a cerrar.
     * @param bufferedWriter  El escritor de flujo de salida a cerrar.
     */
    public void closeEverything(Socket socket, BufferedReader bufferedReader, BufferedWriter bufferedWriter){
        removeClientHandler();
        try{
            if (bufferedReader != null){
                bufferedReader.close();
            }
            if (bufferedWriter != null){
                bufferedWriter.close();
            }
            if (socket != null){
                socket.close();
            }
        } catch (IOException e){
            e.printStackTrace();
        }

    }

    private void startGame(Boolean gameInProgress) {
        System.out.println("Llegue please");
        System.out.println(waitingClients.size());
        System.out.println(ListoJugar.size());
        System.out.println(clientHandlers.size());
        System.out.println(gameInProgress);
        
        //System.out.println(Server.waitingClients.size());
        if (gameInProgress) {
        if (waitingClients.size() >= 2) {
            System.out.println("Llegue pleaseV2");
            gameInProgress = true;
            Client_Handler player1 = waitingClients.get(0);
            Client_Handler player2 = waitingClients.get(1);
    
            // Inicia el juego con player1 y player2
            Thread thread1 = new Thread(player1);
            Thread thread2 = new Thread(player2);
            thread1.start();
            thread2.start();
        } else {
            System.out.println("Llegue pleaseV34");
            gameInProgress = false;
        }
    }
    }
    
    
}
