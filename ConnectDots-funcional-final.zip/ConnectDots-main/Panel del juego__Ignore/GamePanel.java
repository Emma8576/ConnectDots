import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.*;

import com.fazecast.jSerialComm.SerialPort;

import java.util.*;
import java.io.*;
import java.net.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadLocalRandom;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
// Definición de la clase Node que representa un nodo en una lista enlazada
class Node<T> {
    T data;
    Node<T> next;

    public Node(T data) {
        this.data = data;
        this.next = null;
    }
}

// Definición de la clase LinkedList que implementa una lista enlazada genérica
class LinkedList<T> implements Iterable<T> {
    private Node<T> head;
    private Node<T> tail;

    public LinkedList() {
        head = null;
        tail = null;
    }

    // Método para agregar un elemento al final de la lista
    public void add(T data) {
        Node<T> newNode = new Node<T>(data);
        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            tail = newNode;
        }
    }

    // Método para obtener un elemento en un índice específico
    public T get(int index) {
        if (index < 0) {
            throw new IllegalArgumentException("Index cannot be negative");
        }
        Node<T> current = head;
        int currentIndex = 0;
        while (current != null) {
            if (currentIndex == index) {
                return current.data;
            }
            current = current.next;
            currentIndex++;
        }
        throw new IndexOutOfBoundsException("Index out of bounds");
    }

    // Método para obtener el tamaño de la lista
    public int size() {
        int count = 0;
        Node<T> current = head;
        while (current != null) {
            count++;
            current = current.next;
        }
        return count;
    }

    @Override
    public Iterator<T> iterator() {
        return new LinkedListIterator();
    }

    // Clase interna LinkedListIterator que implementa un iterador para la lista enlazada
    private class LinkedListIterator implements Iterator<T> {
        private Node<T> current = head;

        public boolean hasNext() {
            return current != null;
        }

        public T next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            T data = current.data;
            current = current.next;
            return data;
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    }
}

class Client extends Thread {
    private String identifier; // Almacenar el nuevo identificador de jugador
    private Socket socket;
    private GamePanel gamePanel;


    public Client(String test,Socket socket1,int columna, int fila, String user){
        if(test.equals("comiezo")){
            this.gamePanel = new GamePanel(fila-1, columna-1, this, "", "Test", socket1,user);
        
            try {
            gamePanel.testing(socket1,columna-1,fila-1,user);
        
            }catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    public static void main(String[] args) throws IOException {
        Socket socket4 = null;
        GamePanel gamepanel1 = null;
        Client client = new Client("test",socket4,0,0,"");
        client.connectToServer();
        client.start();
        client.run(gamepanel1,socket4,"");        
    }

    public void connectToServer() {
        
        try {
            final Scanner sc = new Scanner(System.in); // Sirve para obtener la informacón que se encuentra en la terminal la cual fue escrita por el teclado
            System.out.println("Indique el nombre de usuario con el que se desea ingresar");//Captura del nombre de usuario
            String username = sc.nextLine();//Obtiene el usuario escrito
            
            socket = new Socket("127.0.0.1", 3000);
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out.println(username);//Envia el username escrito
            out.flush();
            System.out.println("Connected!!");
                    
            char letter = (char) ('A' + ThreadLocalRandom.current().nextInt(0, 26));
            identifier = Character.toString(letter);

            out.println(identifier);
            out.flush();
            Client client = new Client("test",socket,0,0,"");
            GamePanel gamepanel1 = null;
            System.out.println("username");
            client.run(gamepanel1,socket,username);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void run(GamePanel gamePanel,Socket socket,String user) throws IOException {
        
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(socket.getOutputStream());
            try {
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream());
                String serverMessage;
            
                while ((socket.isConnected())) {
                    try{
                     
                    serverMessage = in.readLine(); 
                    System.out.println(serverMessage);
                 
                    if (serverMessage != null) {
                        if (serverMessage.equals("Test")){
                            if (serverMessage != null) {
                                serverMessage = in.readLine(); 
                                
                                gamePanel.processServerMove(serverMessage);
                            }
                        }

                        if (serverMessage.equals("terminar")){
                            if (serverMessage != null) {
                                out.println("terminar");
                                out.flush();
                                cerrarTodo();
                                
                                
                                
                            }
                        }

                        if (serverMessage.equals("Pintar")){
                            if (serverMessage != null) {
                            
                                serverMessage = in.readLine(); 
                              
                                gamePanel.pinta_socket(serverMessage);
                            }
                        }

                        
                        String[] parts = serverMessage.split(" ");
                        if (parts.length == 3 && parts[0].equals("Inicio")){
                            int columna = Integer.parseInt(parts[1]);
                            int fila = Integer.parseInt(parts[2]);
                            out.println("Primera prubea");
                            out.flush();
                            Client client = new Client("comiezo",socket,columna,fila,user);
                            break;
                        }
                    }
            
                    }catch (Exception E) {
                        E.printStackTrace();
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
    }
    public void sendMoveToServer(int row, int col, Socket socket,int newrow, int newcol) {
        
    try {
         
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
        String moveMessage = "MOVE " + row + " " + col + " " + newrow + " " + newcol; // Formato del mensaje de movimiento
        String testing= "Test";
        out.println(testing);
        out.flush();
        out.println(moveMessage);
        out.flush();
        
    } catch (IOException e) {
        e.printStackTrace();
    }
    
}
    public void sendpintar(int pintar,Socket socket,int row,int col) {
        try {
            
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            String moveMessage1 = "MOVE " + pintar + " " + row + " " + col; // Formato del mensaje de movimiento
            String testing= "Pintar";
            out.println(testing);
            out.flush();
            out.println(moveMessage1);
            out.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }    
    }

    public void pararJuego(Socket socket) {
        try {
            
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            out.println("terminar");
            out.flush();
            //cerrarTodo();
        } catch (IOException e) {
            e.printStackTrace();
        }    
    }
    public void cerrarTodo(){
        try {
            Thread.sleep(7000);
            

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        System.out.println("Program will now exit.");
        
        // Perform the exit after the delay
        System.exit(0);

    }

}


public class GamePanel extends JPanel implements KeyListener {

    public LinkedList<Point2D.Double> points = new LinkedList<Point2D.Double>();
    public LinkedList<Line2D.Double> lines = new LinkedList<Line2D.Double>();
    public LinkedList<Line2D.Double> linescua = new LinkedList<Line2D.Double>();
    public LinkedList<Line2D.Double> linescuauser = new LinkedList<Line2D.Double>();
    public LinkedList<Line2D.Double> linescuarival = new LinkedList<Line2D.Double>();
    public Set<Object> lista = new HashSet<>();
    public Set<Object> coorcuadrado = new HashSet<>();
    public Set<Line2D.Double> paintedLines = new HashSet<>();
    public int currentRow = 0;
    public int currentCol = 0;
    public int NewRow;
    public int NewCol;
    public static int numRows = 8; // Número de filas predeterminado
    public static int numCols = 8; // Número de columnas predeterminado
    public int pointSize = 20;
    public Color selectedLineColor = Color.BLUE;
    public boolean isSelecting = false;
    public Line2D.Double selectedLine = null;
    public Set<Line2D.Double> connectedLines = new HashSet<Line2D.Double>();
    private Clip soundClip;
    private Client client;
    private Socket socket5;
    private int contadorcuauser = 0;
    private int contadorpuuser = 0;
    private int contadorpurival = 0;
    private int puntosUtilizados = 0;
    private int maxPointCount; // Declaración de variable
    private int numLineasVerticales =0;
    private int numLineasHorizontales=0;
    private JTextField jugador1TextField = new JTextField(20);
    private JTextField rivalTextField = new JTextField(20);
    private JTextField mensajeTextField = new JTextField(20);




    // Método principal para ejecutar la aplicación
    public static void main(String[] args) throws IOException {
        Client.main(args);
    }

    public void testing(Socket socket4,int columna,int fila,String user)throws Exception{
        
        JFrame frame = new JFrame();
        //Socket socket4 = null;
        GamePanel stage = new GamePanel(fila,columna,client,"","",socket4,user);
        frame.setBackground(new Color(47, 47, 47));
        frame.setResizable(true);
        frame.add(stage);
        //frame.add(new GamePanel(numRows, numCols));
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        //frame.setBounds(0, 0, 800, 600);
        //frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle(user);
        stage.isSelecting = true;
        Point2D.Double startPoint = stage.points.get(0);
        Point2D.Double endPoint = stage.points.get(1);
        stage.selectedLine = new Line2D.Double(startPoint, endPoint);
        client.run(stage,socket4,user);
        
        }
    
    // Constructor de la clase GamePanel
    public GamePanel(int numRow, int numCol,Client client,String message,String box,Socket socket5, String user) {
        this.socket5 = socket5;
        this.client=client;
        
        //Manejo del sistema
        if(box.equals("Test")){
            processServerMove(message);
        }
        else{
    
            this.client=client;
            this.numRows = numRow;
            this.numCols = numCol;

        ///Inicia Arduino
        
        int BaudRate = 9600;
		int DataBits = 8;
		int StopBits = SerialPort.ONE_STOP_BIT;
		int Parity   = SerialPort.NO_PARITY;

		//Parte de declaración del arduino
        SerialPort [] AvailablePorts = SerialPort.getCommPorts();
		
		System.out.println("\n\n SerialPort Data Reception");

		// use the for loop to print the available serial ports
		System.out.print("\n\n Available Ports ");
		for (int i = 0; i<AvailablePorts.length ; i++)
		{
			System.out.println(i + " - " + AvailablePorts[i].getSystemPortName() + " -> " + AvailablePorts[i].getDescriptivePortName());
		}

        //Open the first Available port
        SerialPort MySerialPort = AvailablePorts[1];
        
        // Set Serial port Parameters
        MySerialPort.setComPortParameters(BaudRate,DataBits,StopBits,Parity);//Sets all serial port parameters at one time

        MySerialPort.setComPortTimeouts(SerialPort.TIMEOUT_READ_BLOCKING, 1000, 0); //Set Read Time outs
                  //.setComPortTimeouts(TIMEOUT_Mode, READ_TIMEOUT_milliSec, WRITE_TIMEOUT_milliSec);
        
        MySerialPort.openPort(); //open the port

        if (MySerialPort.isOpen())
    		System.out.println("\n" + MySerialPort.getSystemPortName() + " is Open ");
        else
   			System.out.println(" Port not open ");

      	MySerialPort.flushIOBuffers();

        //Termina la declaración del Arduino
        ExecutorService executorService = Executors.newSingleThreadExecutor();
    executorService.execute(() -> {
        ArduinoRead(MySerialPort);
    });
        //Termina la declaración del Arduino
           

            
            setFocusable(true);
            addKeyListener(this);

            // Ajustar las dimensiones del panel (tamaño del GamePanel) a pantalla completa
            GraphicsDevice gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
            int screenWidth = gd.getDisplayMode().getWidth();
            int screenHeight = gd.getDisplayMode().getHeight();
            setPreferredSize(new Dimension(screenWidth, screenHeight));
            int panelWidth = getWidth();
            int panelHeight = getHeight();    

            // Inicializar la lista de puntos disponibles para dibujar
            for (int i = 1; i <= numRow + 1; i++) {
                for (int j = 1; j <= numCol + 1; j++) { // Agregar una columna
                    points.add(new Point2D.Double(100 * j, i * 100)); // Agregar una fila
                }
            }

            // Crear un JPanel para las opciones
            JPanel optionsPanel = new JPanel();
            optionsPanel.setLayout(new FlowLayout(FlowLayout.RIGHT)); // Alinea los componentes a la derecha


            //Elementos visuales
            
            JLabel jugador1Label = new JLabel("Jugador:");
            JLabel rivalLabel = new JLabel("Rival:");
            Font font = new Font("Arial", Font.BOLD, 24); // Cambia la fuente y el tamaño según tus necesidades
            mensajeTextField.setFont(font);
            
            


            //Añadir elementos
            //optionsPanel.add(backButton);
            optionsPanel.add(jugador1Label);
            optionsPanel.add(jugador1TextField);
            optionsPanel.add(mensajeTextField, BorderLayout.EAST);
            optionsPanel.add(rivalLabel);
            optionsPanel.add(rivalTextField);
            this.setBackground(new Color(173, 216, 230)); // Establece el fondo en celeste
            optionsPanel.setBackground(new Color(220, 220, 220));


 
            numLineasVerticales = (numCol + 1) * numRow;
            numLineasHorizontales = (numRow + 1) * numCol;
            maxPointCount = numLineasHorizontales+numLineasVerticales;

            // Agregar el panel de opciones a tu GamePanel
            this.setLayout(new BorderLayout());
            this.add(optionsPanel, BorderLayout.NORTH); // Agrega el panel en la esquina superior derecha
            // Asegura de que el panel de opciones sea visible
            optionsPanel.setVisible(true);

            /////////////////////////////Dejar por aparte
            Socket socket4 = null;
            new Client("",socket4,0,0,"").start();
            // Cargar el archivo de sonido
            try {
                File soundFile = new File("sounds/ping.wav");
                AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFile);
                soundClip = AudioSystem.getClip();
                soundClip.open(audioIn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

       
    }
    
    // Método para dibujar en el panel
    public void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        Graphics2D g2 = (Graphics2D) graphics;
        Graphics2D g3 = (Graphics2D) graphics;
        Graphics2D g4 = (Graphics2D) graphics;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setStroke(new BasicStroke(4));

        g2.setColor(Color.BLUE);
        for (Line2D.Double l : lines) {
            g2.setColor(Color.ORANGE);
            if (paintedLines.contains(l)) {
                // Cambia el color de la línea para indicar que ya está pintada
                g2.setColor(Color.RED); // Puedes elegir otro color o estilo
            }
            g2.drawLine((int) l.getX1(), (int) l.getY1(), (int) l.getX2(), (int) l.getY2());
        }

        for (Point2D.Double p : points) {
            g2.setColor(Color.darkGray);
            g2.fillRoundRect((int) (p.x - (pointSize / 2)), (int) (p.y - (pointSize / 2)), pointSize, pointSize, pointSize, pointSize);
        }

        if (isSelecting && selectedLine != null) {
            
            g2.setColor(selectedLineColor);
            g2.drawLine((int) selectedLine.getX1(), (int) selectedLine.getY1(), (int) selectedLine.getX2(), (int) selectedLine.getY2());
                        
        }
        //g2.setColor(Color.GREEN);
        this.contadorcuauser = 0;
        if(contadorcuauser == 0){
            this.contadorcuauser = 1;
            g3.setColor(Color.GREEN);
        for (Line2D.Double m : linescuauser) {
            g3.drawLine((int) m.getX1(), (int) m.getY1(), (int) m.getX2(), (int) m.getY2());
        }

        
    }
    this.contadorcuauser = 1;
    if(contadorcuauser == 1){
        g4.setColor(Color.GRAY);
        for (Line2D.Double h : linescuarival) {
            g4.drawLine((int) h.getX1(), (int) h.getY1(), (int) h.getX2(), (int) h.getY2());
        }
    }

    }

    public void ArduinoRead(SerialPort MySerialPort){
        
        try 
      	{
   			while (true)
   			{
      			byte[] readBuffer = new byte[100];
      			int numRead = MySerialPort.readBytes(readBuffer, readBuffer.length);
      			//System.out.print("Read " + numRead + " bytes -");
      			//System.out.println(readBuffer);
      			String S = new String(readBuffer, "UTF-8").trim(); //convert bytes to String
      			//System.out.println("Received -> "+ S);
                
                if (S.equals("Izquierda") || S.equals("Derecha") || S.equals("Arriba") || S.equals("Abajo")|| S.equals("Enter")) {
                    System.out.println("Movimiento válido: " + S);
                    if(S.equals("Derecha")){
                        keyPressed(new KeyEvent(this, KeyEvent.KEY_PRESSED, System.currentTimeMillis(), 0, KeyEvent.VK_RIGHT, KeyEvent.CHAR_UNDEFINED));              
                    }else if(S.equals("Izquierda")){
                        keyPressed(new KeyEvent(this, KeyEvent.KEY_PRESSED, System.currentTimeMillis(), 0, KeyEvent.VK_LEFT, KeyEvent.CHAR_UNDEFINED));              
                    }else if(S.equals("Arriba")){
                        keyPressed(new KeyEvent(this, KeyEvent.KEY_PRESSED, System.currentTimeMillis(), 0, KeyEvent.VK_UP, KeyEvent.CHAR_UNDEFINED));              
                    }else if(S.equals("Abajo")){
                        keyPressed(new KeyEvent(this, KeyEvent.KEY_PRESSED, System.currentTimeMillis(), 0, KeyEvent.VK_DOWN, KeyEvent.CHAR_UNDEFINED));              
                    }else if(S.equals("Enter")){
                        keyPressed(new KeyEvent(this, KeyEvent.KEY_PRESSED, System.currentTimeMillis(), 0, KeyEvent.VK_ENTER, KeyEvent.CHAR_UNDEFINED));              
                    }
                } else {
                    //System.out.println("Comando no válido: " + S);
                    // Maneja otros comandos o datos no válidos de Arduino según sea necesario.
                }
   			}
		} 
		catch (Exception e) 
			{
			 e.printStackTrace(); 
			}
        }

    // Método para manejar eventos de teclado
    @Override
    public void keyPressed(KeyEvent e) {
        System.out.println(e);
        System.out.println("Wos");
        int keyCode = e.getKeyCode();
        System.out.println(e);


        if (keyCode == KeyEvent.VK_ENTER) {


            if (isSelecting && selectedLine != null) {
                String puntos = (" "+selectedLine.getP1()+selectedLine.getP2());
                if(lista.contains(puntos)){
                    System.out.println("No se puede pintar");
                }else{
                lines.add(selectedLine);
                connectedLines.add(selectedLine);
                //Nuevo código
                String puntos1 = (" "+selectedLine.getP1()+selectedLine.getP2());
                String puntosinverso = (" "+selectedLine.getP2()+selectedLine.getP1());
                lista.add(puntos1);
                lista.add(puntosinverso);
                puntosUtilizados += 1;

                isSelecting = false;
                selectedLine = null;
                //Reproducir el sonido de las conexiones
                playPingSound();
                
                client.sendpintar(keyCode,socket5,currentRow,currentCol);
                this.contadorcuauser = 0;
                verificarCuadrados();
            }
            } 
            else {
                isSelecting = true;
                Point2D.Double startPoint = points.get(currentRow * (numCols + 1) + currentCol);
   

                selectedLine = new Line2D.Double(startPoint, startPoint);
                client.sendpintar(keyCode,socket5,currentRow,currentCol);
            }
        } else if (isSelecting) {
            int newRow = currentRow;
            int newCol = currentCol;

            if (keyCode == KeyEvent.VK_LEFT && currentCol > 0) {
                newCol--;
            } else if (keyCode == KeyEvent.VK_RIGHT && currentCol < numCols) {
                newCol++;
            } else if (keyCode == KeyEvent.VK_UP && currentRow > 0) {
                newRow--;
            } else if (keyCode == KeyEvent.VK_DOWN && currentRow < numRows) {
                newRow++;
            }

            Point2D.Double currentPoint1 = points.get(currentRow * (numCols + 1) + currentCol);
            Point2D.Double newPoint1 = points.get(newRow * (numCols + 1) + newCol);

            selectedLine.setLine(currentPoint1, newPoint1);


            //Punto 0,0
            if(currentRow == 0 && currentCol == 0 && newRow == 0 && newCol == 0){
                currentRow = newRow;
                currentCol = newCol;
                NewRow = newRow;
                NewCol = newCol;
            client.sendMoveToServer(currentRow,currentCol,socket5,NewRow,NewCol);
            }
                else if(currentRow == 0 && newRow == 0 && currentCol == 0 && newCol == 1){
                currentRow = newRow;
                currentCol = newCol;
                NewRow = newRow;
                NewCol = newCol;
            client.sendMoveToServer(currentRow,currentCol-1,socket5,NewRow,NewCol);
            }
            else if(currentRow == newRow && currentCol < newCol ){
          
                currentRow = newRow;
                currentCol = newCol;
                NewRow = newRow;
                NewCol = newCol;
                client.sendMoveToServer(currentRow,currentCol,socket5,NewRow,NewCol-1);
            }
            //Fuera del mapa
            else if(currentRow == newRow && currentCol == newCol ){
              
                currentRow = newRow;
                currentCol = newCol;
                NewRow = newRow;
                NewCol = newCol;
                client.sendMoveToServer(currentRow,currentCol,socket5,NewRow,NewCol);
            }
            
            //Izquierda
            else if(currentRow == newRow && currentCol > newCol ){
                
                currentRow = newRow;
                currentCol = newCol;
                NewRow = newRow;
                NewCol = newCol;
                client.sendMoveToServer(currentRow,currentCol,socket5,NewRow,NewCol+1);
            }
            //Arriba
            else if(currentCol == newCol && currentRow>newRow ){
            
                currentRow = newRow;
                currentCol = newCol;
                NewRow = newRow;
                NewCol = newCol;
                client.sendMoveToServer(currentRow,currentCol,socket5,NewRow+1,NewCol);
            }
            //Abajo
            else if(currentCol == newCol && currentRow<newRow ){
         
                currentRow = newRow;
                currentCol = newCol;
                NewRow = newRow;
                NewCol = newCol;
                client.sendMoveToServer(currentRow,currentCol,socket5,NewRow-1,NewCol);
            }
            
        }
        repaint();

    }

    // Método para reproducir el sonido "ping.wav"
    private void playPingSound() {
        try {
            if (soundClip != null) {
                soundClip.stop();
                soundClip.setFramePosition(0); // Reiniciar al principio
                soundClip.start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }
    
    
    public void processServerMove(String moveMessage) {
        String[] parts = moveMessage.split(" ");
        if (parts.length == 5 && parts[0].equals("MOVE")) {
            
            int row = Integer.parseInt(parts[1]);
            int col = Integer.parseInt(parts[2]);
            int newrow = Integer.parseInt(parts[3]);
            int newcol = Integer.parseInt(parts[4]);
            
        
            Point2D.Double startPoint = points.get(row * (numCols + 1) + col);
            selectedLine = new Line2D.Double(startPoint, startPoint);
            
            Point2D.Double currentPoint = points.get(row * (numCols + 1) + col);
            Point2D.Double newPoint = points.get(newrow * (numCols + 1) + newcol);
            selectedLine.setLine(newPoint, currentPoint);
            repaint(); 
            
        }
    }

    public void pinta_socket(String moveMessage) {
        
        String[] parts = moveMessage.split(" ");
        if (parts.length == 4 && parts[0].equals("MOVE")) {


            int key = Integer.parseInt(parts[1]);
            int row = Integer.parseInt(parts[2]);
            int col = Integer.parseInt(parts[3]);

            if (key == KeyEvent.VK_ENTER) {


            if (isSelecting && selectedLine != null) {
                String puntos = (" "+selectedLine.getP1()+selectedLine.getP2());
                if(lista.contains(puntos)){
                    System.out.println("No se puede pintar");
                }else{
                    
                lines.add(selectedLine);
                connectedLines.add(selectedLine);
                //Nuevo código
                String puntos1 = (" "+selectedLine.getP1()+selectedLine.getP2());
                String puntosinverso = (" "+selectedLine.getP2()+selectedLine.getP1());
                lista.add(puntos1);
                lista.add(puntosinverso);

                isSelecting = false;
                selectedLine = null;
                //Reproducir el sonido de las conexiones
                playPingSound();
                this.contadorcuauser = 1;
                puntosUtilizados += 1;
                verificarCuadrados();
            }
            } 
            else {
                isSelecting = true;
                Point2D.Double startPoint = points.get(currentRow * (numCols + 1) + currentCol);

                selectedLine = new Line2D.Double(startPoint, startPoint);
            }
        }
        }
    }
    public void parartodo(int contadorrival, int contadoruser) {
        repaint();
        if(contadorrival > contadoruser){
            System.out.println("El Rival es el ganador");
            mensajeTextField.setText("El Rival es el ganador");
            repaint();
        }    
        if(contadoruser > contadorrival){
            System.out.println("Usted es el ganador");
            mensajeTextField.setText("Usted es el ganador");
            repaint();
        }
        
        if(contadoruser == contadorrival){
            System.out.println("El resultado es un empate");
            mensajeTextField.setText("El resultado es un empate");
            repaint();
        }  
        repaint();
       
        client.pararJuego(socket5);
        


        //System.exit(0);    
    }
    
    public void verificarCuadrados() {
        // Recorrer el array de líneas
        for (int i = 0; i < lines.size(); i++) {
            Line2D.Double linea1 = lines.get(i);
    
            for (int j = i + 1; j < lines.size(); j++) {
                Line2D.Double linea2 = lines.get(j);
    
                for (int k = j + 1; k < lines.size(); k++) {
                    Line2D.Double linea3 = lines.get(k);
    
                    for (int l = k + 1; l < lines.size(); l++) {
                        Line2D.Double linea4 = lines.get(l);
    
                        // Verificar si estas cuatro líneas forman un cuadrado
                        if (esCuadrado(linea1, linea2, linea3, linea4)) {
                            if(this.contadorcuauser==0){
                            linescuauser.add(linea1);
                            linescuauser.add(linea2);
                            linescuauser.add(linea3);
                            linescuauser.add(linea4);
                            
                            this.contadorpuuser = contadorpuuser+1;
                            jugador1TextField.setText(String.valueOf(""));
                            jugador1TextField.setText(String.valueOf(contadorpuuser));
                             
                            }else if(this.contadorcuauser==1){
                            linescuarival.add(linea1);
                            linescuarival.add(linea2);
                            linescuarival.add(linea3);
                            linescuarival.add(linea4);
                            this.contadorpurival = contadorpurival+1;
                            rivalTextField.setText(String.valueOf(""));
                            rivalTextField.setText(String.valueOf(contadorpurival));
                            }
                            // Realiza acciones adicionales aquí si se encuentra un cuadrado
                        }
                        
                    }
                }
            }
        }
        if (puntosUtilizados >= maxPointCount) {
            System.out.println("No se pueden hacer más líneas.");
            parartodo(contadorpurival,contadorpuuser);
            // Realiza acciones adicionales si es necesario cuando no se pueden hacer más líneas
        }
        
    }
    

    private boolean esCuadrado(Line2D.Double linea1, Line2D.Double linea2, Line2D.Double linea3, Line2D.Double linea4) {

        double longitud1 = linea1.getP1().distance(linea1.getP2());
        double longitud2 = linea2.getP1().distance(linea2.getP2());
        double longitud3 = linea3.getP1().distance(linea3.getP2());
        double longitud4 = linea4.getP1().distance(linea4.getP2());

        String puntoslista69 = (" "+linea1.getP1()+linea1.getP2()+(" "+linea2.getP1()+linea2.getP2()))+(" "+linea3.getP1()+linea3.getP2())+(" "+linea4.getP1()+linea4.getP2());


        boolean cruzan12 = linea1.intersectsLine(linea2);
        boolean cruzan23 = linea2.intersectsLine(linea3);
        boolean cruzan34 = linea3.intersectsLine(linea4);
        boolean cruzan41 = linea4.intersectsLine(linea1);

        if(!coorcuadrado.contains(puntoslista69)){

        if((cruzan12 && cruzan23 && cruzan34 && cruzan41)){
            
            boolean longitud = ((longitud1 == longitud2) && (longitud2 == longitud3) && (longitud3 == longitud4));

            
            double tolerancia = 1.0; // 1 grado

            // Verificar si los ángulos son aproximadamente 90 grados
            boolean cruzanEnUnPunto = cruzan12 && cruzan23 && cruzan34 && cruzan41;

            // Verificar si todas las intersecciones son puntos únicos (evitar líneas superpuestas)
            boolean interseccionesUnicas = getIntersectionsCount(linea1, linea2, linea3, linea4) == 4;

            boolean angulos90Grados = Math.abs(calcularAnguloEntreLineas(linea1, linea2) - 90) < tolerancia &&
                Math.abs(calcularAnguloEntreLineas(linea2, linea3) - 90) < tolerancia &&
                Math.abs(calcularAnguloEntreLineas(linea3, linea4) - 90) < tolerancia &&
                Math.abs(calcularAnguloEntreLineas(linea4, linea1) - 90) < tolerancia;

            if (cruzanEnUnPunto && interseccionesUnicas) {

            String puntoslista1 = (" "+linea1.getP1()+linea1.getP2()+(" "+linea2.getP1()+linea2.getP2()))+(" "+linea3.getP1()+linea3.getP2())+(" "+linea4.getP1()+linea4.getP2());
            
            coorcuadrado.add(puntoslista1);
            return (longitud1 == longitud2) && (longitud2 == longitud3) && (longitud3 == longitud4);
            }
        }else{
            return(false);
        }
        
    }
    return(false);
    }

    // Calcular el ángulo entre dos vectores
    private double calcularAnguloEntreLineas(Line2D.Double linea1, Line2D.Double linea2) {
        // Obtener los ángulos de ambas líneas utilizando la función Math.atan2
        double angulo1 = Math.atan2(linea1.getY2() - linea1.getY1(), linea1.getX2() - linea1.getX1());
        double angulo2 = Math.atan2(linea2.getY2() - linea2.getY1(), linea2.getX2() - linea2.getX1());
    
        // Convertir los ángulos a grados
        angulo1 = Math.toDegrees(angulo1);
        angulo2 = Math.toDegrees(angulo2);
    
        // Calcular la diferencia de ángulos (puede ser negativa o positiva)
        double diferenciaAngulos = angulo1 - angulo2;
    
        // Asegurarse de que la diferencia esté en el rango de -180 a 180 grados
        if (diferenciaAngulos > 180) {
            diferenciaAngulos -= 360;
        } else if (diferenciaAngulos < -180) {
            diferenciaAngulos += 360;
        }
        // Devolver el valor absoluto de la diferencia de ángulos
        return Math.abs(diferenciaAngulos);
    }
    private int getIntersectionsCount(Line2D.Double... lines) {
        // Contar el número de intersecciones únicas entre las líneas
        Set<Point2D.Double> intersections = new HashSet<>();
    
        for (int i = 0; i < lines.length; i++) {
            for (int j = i + 1; j < lines.length; j++) {
                Line2D.Double line1 = lines[i];
                Line2D.Double line2 = lines[j];
    
                if (line1.intersectsLine(line2)) {
                    // Obtener el punto de intersección
                    double x1 = line1.getX1();
                    double y1 = line1.getY1();
                    double x2 = line1.getX2();
                    double y2 = line1.getY2();
                    double x3 = line2.getX1();
                    double y3 = line2.getY1();
                    double x4 = line2.getX2();
                    double y4 = line2.getY2();
    
                    double denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4);
    
                    if (denom != 0) {
                        double px = ((x1 * y2 - y1 * x2) * (x3 - x4) - (x1 - x2) * (x3 * y4 - y3 * x4)) / denom;
                        double py = ((x1 * y2 - y1 * x2) * (y3 - y4) - (y1 - y2) * (x3 * y4 - y3 * x4)) / denom;
                        intersections.add(new Point2D.Double(px, py));
                    }
                }
            }
        }
    
        return intersections.size();
    }
    
    
}