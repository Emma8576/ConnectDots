import java.io.*;
import java.net.*;
import java.util.ArrayList;
/* 
class ClientHandler extends Thread {
    private Socket clientSocket;
    private PrintWriter out;
    private ClientHandler next;
    private static int nextIdentifier = 1;
    private int contador1;
    public static ArrayList<ClientHandler> clientHandlers = new ArrayList<>();
    private Socket socket;
    private BufferedReader bufferedReader;
    private BufferedWriter bufferedWriter;
    private String clientUsername;

    public ClientHandler(Socket socket,int contador) {
        
        System.out.println(contador);
        try {
            this.socket = socket;
            this.contador1 = contador;
            this.clientSocket = socket;
            this.bufferedWriter =new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())); 
            this.bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.clientUsername = bufferedReader.readLine(); 
            clientHandlers.add(this);
            System.out.println(clientUsername);
            broadcast("SERVER: "+clientUsername+" ha entrado al chat!");
            
            System.out.println(contador);

            this.out = new PrintWriter(socket.getOutputStream(), true);
        } catch (IOException e) {
            e.printStackTrace();
        }  
    }

    public void run() {
        String messageFromClient;
        try {
            // Obtener flujos de entrada y salida del cliente
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream());

            int identifier = getNextIdentifier();
            out.println(identifier);

            // Agregar el manejador del cliente a la lista enlazada
            //addClient(this);

            // Notificar a todos los clientes que un nuevo usuario se ha conectado
            String newUserMessage = "Nuevo usuario conectado: " + clientSocket.getInetAddress().getHostAddress();
            broadcastMessage(newUserMessage);

            System.out.println(contador1);
            if (contador1==2){
            contador1 = contador1 +1;
                
            messageFromClient = "e";
            messageFromClient = in.readLine();
                String messageToSend = "Cliente " + clientSocket.getInetAddress().getHostAddress() + ": " + messageFromClient;
                broadcastMessage(messageToSend);
                String ahh = "Inicio";
                broadcast(ahh);
            
            boolean manzana = true;
            while (manzana == true) {
                // Procesa y retransmite el mensaje a todos los clientes
                messageFromClient = in.readLine();
                System.out.println(messageFromClient);
                broadcastMessage(messageFromClient);
                //break;
                

                
            }

                if (messageFromClient == "4") {
                    manzana = false;
    // Code to execute if the condition is true
}

            

            // El cliente ha salido del bucle, por lo que se elimina de la lista enlazada y se notifica a los demás
            removeClient(this);
            String userLeftMessage = "Usuario desconectado: " + clientSocket.getInetAddress().getHostAddress();
            broadcastMessage(userLeftMessage);

            // Cierra la conexión con el cliente
            clientSocket.close();
        }
        } catch (IOException e) {
            // Maneja la excepción de E/S cuando el cliente se desconecta
            System.out.println("Cliente desconectado desde " + clientSocket.getInetAddress().getHostAddress());
            removeClient(this);
            String userLeftMessage = "Usuario desconectado: " + clientSocket.getInetAddress().getHostAddress();
           broadcastMessage(userLeftMessage);
        }
    }
    private static synchronized int getNextIdentifier() {
        return nextIdentifier++;
    }

    // Método para enviar un mensaje en broadcast a todos los clientes
    public void broadcastMessage(String message) {
        for(ClientHandler clientHandler: clientHandlers){
            try{
                if (!clientHandler.clientUsername.equals(clientUsername)){
                    clientHandler.bufferedWriter.write(message);
                    clientHandler.bufferedWriter.newLine();
                    clientHandler.bufferedWriter.flush();
                }
            }catch(IOException e) {
                
            }
        }
    }
    public void broadcast(String message) {
        ClientHandler current = firstClient;
        while (current != null) {
            current.out.println(message);
            current = current.next;
        }
    }


    // Implementa una lista enlazada personalizada para los clientes
    private static ClientHandler firstClient;

    private static void addClient(ClientHandler client) {
        if (firstClient == null) {
            firstClient = client;
        } else {
            ClientHandler current = firstClient;
            while (current.next != null) {
                current = current.next;
            }
            current.next = client;
        }
    }

    private static void removeClient(ClientHandler client) {
        if (firstClient == client) {
            firstClient = client.next;
        } else {
            ClientHandler current = firstClient;
            while (current != null && current.next != client) {
                current = current.next;
            }
            if (current != null) {
                current.next = client.next;
            }
        }
    }
}
*/

/////////////////////////////////Sever!!!!!!!!!!!!!!!!!!!!!!!!!

public class Server {
    private ServerSocket serverSocket;
    private Client_Handler clientHandler;

    public Server(ServerSocket serverSocket){
        this.serverSocket = serverSocket;

    }

    public void startServer(int contador){
        try{
            while (true){
                Socket clientSocket = serverSocket.accept();
                System.out.println("Cliente conectado desde " + clientSocket.getInetAddress().getHostAddress());
                contador = contador+1;
                Client_Handler clientHandler = new Client_Handler(clientSocket,contador);
                Thread thread = new Thread(clientHandler);
                thread.start();

            }

        }catch(IOException e){

        }
    }
    
    public static void main(String[] args) {
        try {
            int contador = 0;
            ServerSocket serverSocket = new ServerSocket(3000);
            System.out.println("Servidor esperando conexiones...");
            
            Server server = new Server(serverSocket);
            server.startServer(contador);

                
            


            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    
}


